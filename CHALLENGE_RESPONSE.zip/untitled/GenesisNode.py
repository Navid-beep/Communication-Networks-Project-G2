from Network import Network

peer = Network("localhost") #Node instance is created
peer.start(5050)

#Genesis node is created and started


data=input()

while(True):
	peer.broadcast(data)
	data=input()