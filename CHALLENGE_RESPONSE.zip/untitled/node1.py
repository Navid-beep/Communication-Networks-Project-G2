import json

from Network import Network
import threading
import time
import random
from helpers.terminal_helper import print_colored
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes



key1 = b'\x91\xac\xa0\xa7\xf6\\\xeb;\xaa\xe1\xb0\x8b\xb8\xe7\xdc\xa0'


node1 = Network("127.0.0.1")
node1.start(5051)


#ciphertext_from_client=node1.MSGTOSAVE

###
"""
f= open("tag_node_1.txt", "rb")
tag1_read=f.read();

k= open("nonce_node_1.txt", "rb")
nonce1_read=f.read();


print(f" bla {node1.MSGTOSAVE}")


message=json.loads(node1.MSGTOSAVE)
message=message['message']


print(f"the message printed here bla {message}")


cipher1 = AES.new(key1, AES.MODE_EAX, nonce1_read)
decrypt1=cipher1.decrypt_and_verify(message, tag1_read)

middle_port=decrypt1[-4:]
message_encrypted_to_send=decrypt1[:-4]


print(f" message decrypted is {decrypt1}")
node1.unicastTOR(message_encrypted_to_send, 5052)
print(f" message to send in node 1 is {message_encrypted_to_send}")

"""
####

print("SERVER-1 (Tokyo)")
print_colored("PORT 5051 is started active Press enter to continue","green")
input()


#node2.connectToNode("192.168.56.1",5050)



#node1.connectToNode("192.168.56.1",5055)
#node1.connectToNode("192.168.56.1",5056)


node1.join_network()
#randomNode = node2.askRandNode("192.168.56.1",5050)
while True:
    data1 =input()
    try:
        message = bytes(map(int, node1.MSGTOSAVE.split(' ')))
        f = open("tag_node_1.txt", "rb")
        tag1_read = f.read();
        # print(f"the message printed here bla {message}")
        k = open("nonce_node_1.txt", "rb")
        nonce1_read = k.read();
        cipher1 = AES.new(key1, AES.MODE_EAX, nonce1_read)
        decrypt1 = cipher1.decrypt_and_verify(message, tag1_read)
        middle_port = decrypt1[-4:]
        message_encrypted_to_send = decrypt1[:-4]
        print("The deciphered text is",decrypt1)
        node1.unicastTOR(' '.join(map(str, list(message_encrypted_to_send))), int(middle_port))
        print(f" message sent successfully to node 2 is {message_encrypted_to_send}")
        break
    except:
        print("exception")











