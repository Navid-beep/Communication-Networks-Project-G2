from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


encrypted_message3= "Hello World"

key1 = b'\x91\xac\xa0\xa7\xf6\\xeb;\xaa\xe1\xb0\x8b\xb8\xe7\xdc\xa0'
#texfile for node 1
key2 = b'\xa4\xec\xe0\xa5\xfd\xa9\x17\xba\xfb\xac\xb6\x93I4\xea\x86'
#text file for node 2
key3 = b'\xceO\xdd"\xef\x1fV.\x1c\x835\xbcD\x87\xf5\xad'
# text file for node 3

cipher3 = AES.new(key3, AES.MODE_EAX)
ciphertext3, tag3 = cipher3.encrypt_and_digest(encrypted_message3.encode('ASCII'))


""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
print(f"read tag3: {tag3}")
print(cipher3.nonce)
cipher3.nonce=' '.join(map(str,list(cipher3.nonce)))
print(cipher3.nonce)
print(type(cipher3.nonce))
cipher3.nonce=bytes(map(int,cipher3.nonce.split(' ')))
print(cipher3.nonce)
print(type(cipher3.nonce))
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

cipher1 = AES.new(key3, AES.MODE_EAX, cipher3.nonce)
decrypt1 = cipher1.decrypt_and_verify(ciphertext3, tag3)

print(decrypt1)


#cipher3 = AES.new(key3, AES.MODE_EAX, cipher3.nonce)
#decrypt1=cipher3.decrypt_and_verify(ciphertext3, tag3_read)
print("worked")





#cipher3 = AES.new(key3, AES.MODE_EAX, cipher3.nonce)
#decrypt1=cipher3.decrypt_and_verify(ciphertext3, tag3_read)
print("worked")