import json

from Network import Network
import threading
import time
import random
from helpers.terminal_helper import print_colored
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes



server= Network("127.0.0.1")
server.start(5055)


#ciphertext_from_client=node1.MSGTOSAVE



print("SERVER-4 (London)")
print_colored("PORT 5055 is started active Please enter a key to continue","green")
input()
challenge="is_cool"
password='communication_networks'
server.join_network()
server.unicastTOR(challenge, 5060)
print("Challenge is",challenge)
print("Server: the hash is ",hash(password+challenge))
while True:
    dataserver =input()
       # data1 =input()
       # node1.unicastTOR(data1, 5052)
    print("I GOT A MESSAGE!", bytes(map(int,server.MSGTOSAVE.split())))
        #server.unicastTOR("Message received", 5051)
