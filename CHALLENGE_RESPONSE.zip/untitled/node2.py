import json

from Network import Network
import threading
import time
import random
from helpers.terminal_helper import print_colored
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes



key2= b'\xa4\xec\xe0\xa5\xfd\xa9\x17\xba\xfb\xac\xb6\x93I4\xea\x86'


node2= Network("127.0.0.1")
node2.start(5052)


#ciphertext_from_client=node1.MSGTOSAVE



print("SERVER-2 (Berlin)")
print_colored("PORT 5052 is started active Press enter to continue","green")
input()


#node2.connectToNode("192.168.56.1",5050)



#node1.connectToNode("192.168.56.1",5055)
#node1.connectToNode("192.168.56.1",5056)



node2.join_network()
#randomNode = node2.askRandNode("192.168.56.1",5050)
while True:
    data2 =input()
       # data1 =input()
       # node1.unicastTOR(data1, 5052)
    try:
        message = bytes(map(int, node2.MSGTOSAVE.split(' ')))
        f = open("tag_node_2.txt", "rb")
        tag2_read = f.read();
        # print(f"the message printed here bla {message}")
        k = open("nonce_node_2.txt", "rb")
        nonce2_read = k.read();
        cipher2 = AES.new(key2, AES.MODE_EAX, nonce2_read)
        decrypt2 = cipher2.decrypt_and_verify(message, tag2_read)
        end_port = decrypt2[-4:]
        message_encrypted_to_send = decrypt2[:-4]
        print("The deciphered text is",decrypt2)
        node2.unicastTOR(' '.join(map(str, list(message_encrypted_to_send))), int(end_port))
        print(f" message sent successfully to node 3 is {message_encrypted_to_send}")
        break
    except:
        print("exception")










