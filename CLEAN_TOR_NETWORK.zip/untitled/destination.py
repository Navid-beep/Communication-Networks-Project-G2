import json

from Network import Network
import threading
import time
import random
from helpers.terminal_helper import print_colored
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes



destination= Network("127.0.0.1")
destination.start(5055)


#ciphertext_from_client=node1.MSGTOSAVE



print("SERVER-4 (London)")
print_colored("PORT 5055 is started active Please enter a key to continue","green")
input()


#node3.connectToNode("192.168.56.1",5050)



#node1.connectToNode("192.168.56.1",5055)
#node1.connectToNode("192.168.56.1",5056)


destination.join_network()
while True:
    datadestination =input()
       # data1 =input()
       # node1.unicastTOR(data1, 5052)
    print("I GOT A MESSAGE!", bytes(map(int,destination.MSGTOSAVE.split())))
        #destination.unicastTOR("Message received", 5051)
