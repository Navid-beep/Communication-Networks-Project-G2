a=b'111'
b=' '.join(map(str, list(a)))
