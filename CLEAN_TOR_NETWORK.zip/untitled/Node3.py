import json

from Network import Network
import threading
import time
import random
from helpers.terminal_helper import print_colored
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes



key3=  b'\xceO\xdd"\xef\x1fV.\x1c\x835\xbcD\x87\xf5\xad'


node3= Network("127.0.0.1")
node3.start(5053)


#ciphertext_from_client=node1.MSGTOSAVE



print("SERVER-3 (Paris)")
print_colored("PORT 5053 is started active Press enter to continue","green")
input()


#node3.connectToNode("192.168.56.1",5050)



#node1.connectToNode("192.168.56.1",5055)
#node1.connectToNode("192.168.56.1",5056)



node3.join_network()
#randomNode = node3.askRandNode("192.168.56.1",5050)
while True:
    data3 =input()
    try:
        message = bytes(map(int, node3.MSGTOSAVE.split(' ')))
        f = open("tag_node_3.txt", "rb")
        tag3_read = f.read();
        # print(f"the message printed here bla {message}")
        k = open("nonce_node_3.txt", "rb")
        nonce3_read = k.read();
        cipher3 = AES.new(key3, AES.MODE_EAX, nonce3_read)
        decrypt3 = cipher3.decrypt_and_verify(message, tag3_read)
        destination = decrypt3[-4:]
        message_encrypted_to_send = decrypt3[:-4]
        print("The deciphered text is",decrypt3)
        node3.unicastTOR(' '.join(map(str, list(message_encrypted_to_send))), int(destination))
        print(f" message sent successfully to destination is {message_encrypted_to_send}")
        break
    except:
        print("exception")
