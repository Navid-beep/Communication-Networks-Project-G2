a="het"
print(a)
