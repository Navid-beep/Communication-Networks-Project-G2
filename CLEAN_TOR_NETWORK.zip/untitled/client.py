from Network import Network
import threading
import time
import random
import json
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


from helpers.terminal_helper import print_colored

#node 1 is the start
#node 2 is the middle
#node 3 is the end


client = Network("127.0.0.1")
client.start(5060)

client.MSGTOSAVE=input();
"""
destination_port_number="5054"

encrypted_message3= client.MSGTOSAVE+destination_port_number

key1 = b'\x91\xac\xa0\xa7\xf6\\\xeb;\xaa\xe1\xb0\x8b\xb8\xe7\xdc\xa0'
#texfile for node 1
key2 = b'\xa4\xec\xe0\xa5\xfd\xa9\x17\xba\xfb\xac\xb6\x93I4\xea\x86'
#text file for node 2
key3 = b'\xceO\xdd"\xef\x1fV.\x1c\x835\xbcD\x87\xf5\xad'
# text file for node 3

cipher = AES.new(key3, AES.MODE_EAX)
ciphertext3, tag = cipher.encrypt_and_digest(encrypted_message3.encode('ASCII'))

end_port_number="5053"
encrypted_message2=ciphertext3+end_port_number
cipher = AES.new(key2, AES.MODE_EAX)
ciphertext2, tag = cipher.encrypt_and_digest(encrypted_message2.encode('ASCII'))


middle_port_number="5052"
encrypted_message1=ciphertext2+end_port_number
cipher = AES.new(key1, AES.MODE_EAX)
ciphertext1, tag = cipher.encrypt_and_digest(encrypted_message1.encode('ASCII'))
"""
destination_port_number="1922"


encrypted_message3= "Hello World"+destination_port_number

key1 = b'\x91\xac\xa0\xa7\xf6\\\xeb;\xaa\xe1\xb0\x8b\xb8\xe7\xdc\xa0'
#texfile for node 1
key2 = b'\xa4\xec\xe0\xa5\xfd\xa9\x17\xba\xfb\xac\xb6\x93I4\xea\x86'
#text file for node 2
key3 = b'\xceO\xdd"\xef\x1fV.\x1c\x835\xbcD\x87\xf5\xad'
# text file for node 3







print("SERVER-2 (Belgium)")
print_colored("PORT 5051 is started active Press enter to continue","green")
input()


#node2.connectToNode("192.168.56.1",5050)


"""node2.connectToNode("192.168.56.1",5055)
node2.connectToNode("192.168.56.1",5056)

"""

client.join_network()
#randomNode = node2.askRandNode("192.168.56.1",5050)

data=0

i = 0 #start the key transmission

#get N random numbers to connect (nodes)



#keys = []


#while True:
input()
print("Please enter the secret message")
encrypted_message3 =input()
print("The destination port number is 5055")
encrypted_message3=encrypted_message3+"5055"
cipher3 = AES.new(key3, AES.MODE_EAX)
ciphertext3, tag3 = cipher3.encrypt_and_digest(encrypted_message3.encode('ASCII'))

f = open("tag_node_3.txt", "wb")
f.write(tag3)
f.close()

f = open("nonce_node_3.txt", "wb")
f.write(cipher3.nonce)
f.close()

end_port_number = "5053"

encrypted_message2 = ciphertext3 + end_port_number.encode(('ASCII'))
cipher2 = AES.new(key2, AES.MODE_EAX)
ciphertext2, tag2 = cipher2.encrypt_and_digest(encrypted_message2)

f = open("tag_node_2.txt", "wb")
f.write(tag2)
f.close()

f = open("nonce_node_2.txt", "wb")
f.write(cipher2.nonce)
f.close()

middle_port_number = "5052"
encrypted_message1 = ciphertext2 + middle_port_number.encode(('ASCII'))

cipher1 = AES.new(key1, AES.MODE_EAX)
ciphertext1, tag1 = cipher1.encrypt_and_digest(encrypted_message1)

f = open("tag_node_1.txt", "wb")
f.write(tag1)
f.close()

f = open("nonce_node_1.txt", "wb")
f.write(cipher1.nonce)
f.close()
print("This is the ciphered text",ciphertext1)

ciphertext1 = ' '.join(map(str, list(ciphertext1)))


client.MSGTOSAVE = ciphertext1
client.cipher1_nonce = cipher1.nonce
#keys.append(client.MSGTOSAVE[""])
client.unicastTOR(ciphertext1, 5051)






