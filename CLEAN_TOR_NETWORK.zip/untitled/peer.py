from Network import Network

peer = Network("localhost") #Node instance is created
peer.start(5054)

#A peer started


data = input()

while(True):
	peer.broadcast(data)
	data=input()