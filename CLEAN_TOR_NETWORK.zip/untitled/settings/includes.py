import socket
import time
import threading
import commands
import random
import json
import hashlib

from settings.terminal_set import bcolors
from helpers.terminal_helper import print_colored



import os


os.system("color")

